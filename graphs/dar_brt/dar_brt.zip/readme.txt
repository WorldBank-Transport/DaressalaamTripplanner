DAR ES SALAAM TRIPPLANNER

1.Currently there are BRT routes(29) but with only (28) BRT stops, these stops can be used for routes through Morogoro road and kawawa road.

2.There are two bus routes mbezi-posta and makumbusho-posta. To integrate these routes in the tool, bus stops and bus routes shapefiles are needed. After that the shapefiles will be converted to gtfs files which will be used added to the dar es salaam map.

3.There is one rail route ubungo-posta. Here rail routes and rail stops shapefiles will be used to generate the gtfs.
DAR ES SALAAM TRIPPLANNER

This is a multimodal dar es salaam tripplanner using BRT and daladala as main transit agencies.
User can view different possible trip itineraries if the used points are within dar es salaam region and are not on the residential streets.

HOW IT WORKS.

1.There are BRT routes(29) with (172) BRT stops, these stops can be used for routes through Morogoro road and kawawa road.

2.There are all bus routes. To integrate these routes in the tool, bus stops and bus routes shapefiles are needed. After that the shapefiles will be converted to gtfs files which will be used added to the dar es salaam map.

3.There is one rail route ubungo-posta. Here rail routes and rail stops shapefiles will be used to generate the gtfs.

WHY THIS AND NOT GOOGLE MAP

The main difference of this tool and google map is that google map does not provide trip plans from the dar es salaam transit agencies. 


WORK TO DO 

Improving efficiency showing function, this will make user see which itinerary with which agency is more efficiency interms of time.

Fixing analyst function to work perfectly with appropiate colors.

CHALLENGES

The tool doesn't support car navigation.


CONCLUSION

The tool can be access here https://dar-tripplanner.herokuapp.com/


